exec sp_changedbowner 'sa'
